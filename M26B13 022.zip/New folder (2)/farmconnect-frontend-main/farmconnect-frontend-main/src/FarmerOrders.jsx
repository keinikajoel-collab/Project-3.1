import React, { useState } from 'react';
import axios from 'axios';

const STATUS_OPTIONS = ['Pending', 'Confirmed', 'Shipped', 'Completed', 'Cancelled'];

export default function FarmerOrders({ order }) {
    const [currentStatus, setCurrentStatus] = useState(order.status);
    const [loading, setLoading] = useState(false);

    const handleStatusChange = async (e) => {
        const newStatus = e.target.value;
        setLoading(true);
        try {
            await axios.patch(`/api/orders/${order.id}/status`, { status: newStatus }, { withCredentials: true });
            setCurrentStatus(newStatus);
        } catch (err) {
            alert('Failed to update order status');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="border p-4 rounded my-2 flex justify-between items-center bg-white shadow-sm">
            <div>
                <p className="font-bold">Order #{order.id}</p>
                <p className="text-sm text-gray-600">Buyer: {order.buyer_name}</p>
            </div>
            <div>
                <select 
                    value={currentStatus} 
                    onChange={handleStatusChange} 
                    disabled={loading}
                    className="border p-2 rounded bg-gray-50 font-medium"
                >
                    {STATUS_OPTIONS.map((status) => (
                        <option key={status} value={status}>{status}</option>
                    ))}
                </select>
            </div>
        </div>
    );
}