export default function StockBadge({ stockQuantity, threshold = 5 }) {
    if (stockQuantity === 0) {
        return <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded font-semibold">Out of Stock</span>;
    }
    if (stockQuantity <= threshold) {
        return <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded font-semibold">Low Stock ({stockQuantity} left)</span>;
    }
    return <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded font-semibold">In Stock</span>;
}