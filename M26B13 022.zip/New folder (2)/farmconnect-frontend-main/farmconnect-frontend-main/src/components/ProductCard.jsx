import React, { useState } from 'react';
import axios from 'axios';

export default function ProductCard({ product, initialIsFavorite }) {
    const [isFavorite, setIsFavorite] = useState(initialIsFavorite);
    const [loading, setLoading] = useState(false);

    const toggleFavorite = async () => {
        if (loading) return;
        setLoading(true);
        try {
            if (isFavorite) {
                await axios.delete(`/api/favourites/${product.id}`, { withCredentials: true });
                setIsFavorite(false);
            } else {
                await axios.post('/api/favourites', { productId: product.id }, { withCredentials: true });
                setIsFavorite(true);
            }
        } catch (err) {
            console.error('Failed to update favorite status', err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="product-card border p-4 rounded shadow-sm relative">
            <button 
                onClick={toggleFavorite} 
                className="absolute top-3 right-3 text-xl focus:outline-none"
                aria-label="Save to favorites"
            >
                {isFavorite ? '❤️' : '🤍'}
            </button>
            <img src={product.image_url} alt={product.name} className="w-full h-40 object-cover mb-2 rounded" />
            <h3 className="font-bold text-lg">{product.name}</h3>
            <p className="text-gray-600">${product.price}</p>
        </div>
    );
}