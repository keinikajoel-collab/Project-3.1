const ALLOWED_STATUSES = ['Pending', 'Confirmed', 'Shipped', 'Completed', 'Cancelled'];

// PATCH /api/orders/:id/status - Update order status (Farmer or Admin only)
router.patch('/:id/status', authMiddleware, async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const user = req.user; // Contains id and role

        if (!ALLOWED_STATUSES.includes(status)) {
            return res.status(400).json({ error: 'Invalid status value' });
        }

        // Verify ownership if user is a farmer (ensure order contains farmer's products)
        if (user.role === 'farmer') {
            const ownershipCheck = `
                SELECT 1 FROM orders o
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                WHERE o.id = $1 AND p.farmer_id = $2;
            `;
            const checkResult = await pool.query(ownershipCheck, [id, user.id]);
            if (checkResult.rowCount === 0) {
                return res.status(403).json({ error: 'Unauthorized to update this order' });
            }
        }

        const updateQuery = `
            UPDATE orders 
            SET status = $1, updated_at = NOW() 
            WHERE id = $2 
            RETURNING *;
        `;
        const { rows } = await pool.query(updateQuery, [status, id]);

        if (rows.length === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }

        res.json({ message: 'Order status updated successfully', order: rows[0] });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Server error updating order status' });
    }
});