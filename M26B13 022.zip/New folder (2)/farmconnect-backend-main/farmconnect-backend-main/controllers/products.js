// Example inside product route handlers
router.post('/', authMiddleware, async (req, res) => {
    try {
        const farmerId = req.user.id;
        const { name, description, price, stock_quantity, low_stock_threshold } = req.body;

        const query = `
            INSERT INTO products (farmer_id, name, description, price, stock_quantity, low_stock_threshold)
            VALUES ($1, $2, $3, $4, $5, COALESCE($6, 5))
            RETURNING *;
        `;
        const values = [farmerId, name, description, price, stock_quantity || 0, low_stock_threshold];
        const { rows } = await pool.query(query, values);

        res.status(201).json(rows[0]);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Server error creating product' });
    }
});