const express = require('express');
const router = express.Router();
const pool = require('../db'); // Your database connection pool
const authMiddleware = require('../middleware/auth'); // Verifies JWT and attaches req.user

// GET /api/favourites - Fetch all wishlist items for logged-in user
router.get('/', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;
        const query = `
            SELECT p.* FROM products p
            JOIN favourites f ON p.id = f.product_id
            WHERE f.user_id = $1
            ORDER BY f.created_at DESC;
        `;
        const { rows } = await pool.query(query, [userId]);
        res.json(rows);
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Server error fetching favourites' });
    }
});

// POST /api/favourites - Add product to wishlist
router.post('/', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;
        const { productId } = req.body;

        const query = `
            INSERT INTO favourites (user_id, product_id)
            VALUES ($1, $2)
            ON CONFLICT (user_id, product_id) DO NOTHING
            RETURNING *;
        `;
        const { rows } = await pool.query(query, [userId, productId]);
        res.status(201).json({ message: 'Added to favourites', favourite: rows[0] });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Server error adding favourite' });
    }
});

// DELETE /api/favourites/:productId - Remove from wishlist
router.delete('/:productId', authMiddleware, async (req, res) => {
    try {
        const userId = req.user.id;
        const { productId } = req.params;

        const query = `DELETE FROM favourites WHERE user_id = $1 AND product_id = $2;`;
        await pool.query(query, [userId, productId]);
        
        res.json({ message: 'Removed from favourites' });
    } catch (err) {
        console.error(err.message);
        res.status(500).json({ error: 'Server error removing favourite' });
    }
});

module.exports = router;